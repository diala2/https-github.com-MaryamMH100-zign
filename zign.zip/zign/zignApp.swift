//
//  zignApp.swift
//  zign
//
//  Created by Diala Abdulnasser Fayoumi on 08/11/1446 AH.
//
// MARK: - App Entry
import SwiftUI
@main
struct FlowchartApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
