//
//  Untitled.swift
//  zign
//
//  Created by Diala Abdulnasser Fayoumi on 16/11/1446 AH.
//
import SwiftUI
struct FlowchartTool: View {
    let shape: FlowchartShape

    var body: some View {
        VStack {
            switch shape {
            case .rectangle:
                Rectangle().fill(Color.blue).frame(width: 40, height: 40)
            case .diamond:
                Diamond().fill(Color.green).frame(width: 40, height: 40)
            case .oval:
                Ellipse().fill(Color.orange).frame(width: 40, height: 40)
            case .square:
                Rectangle().stroke(Color.purple, lineWidth: 2).frame(width: 40, height: 40)
            case .roundedRectangle:
                RoundedRectangle(cornerRadius: 10).stroke(Color.cyan, lineWidth: 2).frame(width: 50, height: 30)
            case .parallelogram:
                Parallelogram().stroke(Color.mint, lineWidth: 2).frame(width: 50, height: 30)
            case .arrow:
                ArrowSymbol().stroke(Color.black, lineWidth: 2).frame(width: 50, height: 30)
            }

            Text(shape.rawValue)
                .font(.caption2)
                .foregroundColor(.white)
        }
    }
}
