//
//  Untitled.swift
//  zign
//
//  Created by Diala Abdulnasser Fayoumi on 16/11/1446 AH.
//
import SwiftUI

struct FlowchartNode: View {
    let element: FlowchartElement
    let isSelected: Bool

    var body: some View {
        Group {
            switch element.shape {
            case .rectangle:
                Rectangle().fill(Color.blue.opacity(0.2)).frame(width: 200, height: 60)
            case .diamond:
                Diamond().fill(Color.green.opacity(0.2)).frame(width: 120, height: 120)
            case .oval:
                Ellipse().fill(Color.orange.opacity(0.2)).frame(width: 180, height: 60)
            case .square:
                Rectangle().fill(Color.purple.opacity(0.2)).frame(width: 80, height: 80)
            case .roundedRectangle:
                RoundedRectangle(cornerRadius: 15).fill(Color.cyan.opacity(0.2)).frame(width: 150, height: 70)
            case .parallelogram:
                Parallelogram().fill(Color.mint.opacity(0.2)).frame(width: 180, height: 60)
            case .arrow:
                ArrowSymbol().stroke(Color.black, lineWidth: 2).frame(width: 50, height: 30)
            }
        }
        .overlay(
            Text(element.text)
                .foregroundColor(.black)
                .padding(8)
                .multilineTextAlignment(.center)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 4)
                .stroke(isSelected ? Color.red : Color.gray, lineWidth: isSelected ? 3 : 1)
        )
    }
}
