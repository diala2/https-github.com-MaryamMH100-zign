//
//  ArrowSymbol.swift
//  zign
//
//  Created by Diala Abdulnasser Fayoumi on 16/11/1446 AH.
//
//import SwiftUI
//struct ArrowSymbol: Shape {
//    func path(in rect: CGRect) -> Path {
//        var path = Path()
//        let midY = rect.midY
//        path.move(to: CGPoint(x: rect.minX, y: midY))
//        path.addLine(to: CGPoint(x: rect.maxX - 10, y: midY))
//        path.addLine(to: CGPoint(x: rect.maxX - 20, y: midY - 10))
//        path.move(to: CGPoint(x: rect.maxX - 10, y: midY))
//        path.addLine(to: CGPoint(x: rect.maxX - 20, y: midY + 10))
//        return path
//    }
//}
